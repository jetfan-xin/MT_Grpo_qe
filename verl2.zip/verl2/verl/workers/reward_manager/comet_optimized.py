# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
from concurrent.futures import ProcessPoolExecutor
from functools import partial
from typing import Callable, Optional

import psutil
import torch
from transformers import PreTrainedTokenizer

from verl import DataProto
from verl.workers.reward_manager import register


@register("comet_optimized")
class COMETOptimizedRewardManager:
    """
    Optimized COMET Reward Manager that uses batch processing for efficient COMET score computation
    """

    def __init__(self, reward_score_fn: Callable, tokenizer: Optional[PreTrainedTokenizer] = None, device="cuda"):
        super().__init__()
        self.reward_score_fn = reward_score_fn
        self.tokenizer = tokenizer
        self.device = device

    def __call__(self, data: DataProto) -> DataProto:
        """
        Compute rewards using batched COMET processing
        
        Args:
            data: DataProto containing prompts, completions, and metadata
            
        Returns:
            DataProto with computed rewards
        """
        # Extract batch information
        batch_size = len(data)
        rewards = torch.zeros(batch_size, dtype=torch.float32)
        
        # Prepare batch data for COMET processing
        src_texts = []
        tgt_texts = []
        completions = []
        
        for i in range(batch_size):
            data_item = data[i]
            src_text = data_item.non_tensor_batch.get('src_text', '')
            tgt_text = data_item.non_tensor_batch.get('tgt_text', '')
            
            # Decode completion if it's in token form
            if 'responses' in data_item.batch:
                response_ids = data_item.batch['responses']
                if self.tokenizer is not None:
                    completion = self.tokenizer.decode(response_ids, skip_special_tokens=True)
                else:
                    completion = str(response_ids)
            else:
                completion = data_item.non_tensor_batch.get('completion', '')
            
            src_texts.append(src_text)
            tgt_texts.append(tgt_text)
            completions.append(completion)
        
        # Batch compute rewards using the optimized reward function
        try:
            batch_rewards = self.reward_score_fn(
                completions=completions,
                src_texts=src_texts, 
                tgt_texts=tgt_texts,
                batch_processing=True  # Flag to enable batch processing
            )
            
            # Convert to tensor
            if isinstance(batch_rewards, (list, tuple)):
                rewards = torch.tensor(batch_rewards, dtype=torch.float32)
            else:
                rewards = torch.as_tensor(batch_rewards, dtype=torch.float32)
                
        except Exception as e:
            print(f"Batch reward computation failed: {e}, falling back to individual processing")
            # Fallback to individual processing
            for i in range(batch_size):
                try:
                    reward = self.reward_score_fn(
                        completion=completions[i],
                        src_text=src_texts[i],
                        tgt_text=tgt_texts[i],
                        extra_info={'lg': data[i].non_tensor_batch.get('lg', 'en-zh')}
                    )
                    rewards[i] = reward
                except Exception as e2:
                    print(f"Individual reward computation failed for item {i}: {e2}")
                    rewards[i] = -1.0  # Default penalty
        
        # Create output DataProto
        output_data = DataProto.from_dict(tensors={'rewards': rewards})
        return output_data


class BatchedCOMETRewardFunction:
    """
    A batched version of the COMET reward function for improved efficiency
    """
    
    def __init__(self, comet_model_path: str):
        from comet import load_from_checkpoint
        self.comet_model = load_from_checkpoint(comet_model_path)
        self._setup_logging()
    
    def _setup_logging(self):
        import logging
        loggers = [logging.getLogger(name) for name in logging.root.manager.loggerDict]
        for logger in loggers:
            logger.setLevel(logging.WARNING)
    
    def _validate_format(self, completion: str) -> bool:
        """Check if completion has required format tags"""
        import re
        pattern = r'^<think>.*?</think>\s*<translate>.*?</translate>(?![\s\S])'
        return bool(re.match(pattern, completion, re.DOTALL | re.MULTILINE))
    
    def _extract_translation(self, completion: str) -> Optional[str]:
        """Extract translation from completion"""
        import re
        match = re.search(r'<translate>(.*?)</translate>', completion, re.DOTALL)
        return match.group(1).strip() if match else None
    
    def _compute_bleu(self, reference: str, hypothesis: str, lang_pair: str = "en-zh") -> float:
        """Compute BLEU score"""
        import sacrebleu
        
        tgt_lang = lang_pair.split("-")[1]
        tokenize = "zh" if tgt_lang == "zh" else "ja-mecab" if tgt_lang == "ja" else "13a"
        
        bleu = sacrebleu.sentence_bleu(hypothesis, [reference], lowercase=True, tokenize=tokenize)
        return float(bleu.score)
    
    def __call__(self, completions, src_texts, tgt_texts, batch_processing=False, **kwargs):
        """
        Compute rewards with optional batch processing
        
        Args:
            completions: List of completion strings
            src_texts: List of source texts
            tgt_texts: List of target/reference texts
            batch_processing: Whether to use batch processing
        """
        if not batch_processing or len(completions) == 1:
            # Single completion processing (backward compatibility)
            return self._compute_single(
                completion=completions[0] if isinstance(completions, list) else completions,
                src_text=src_texts[0] if isinstance(src_texts, list) else src_texts,
                tgt_text=tgt_texts[0] if isinstance(tgt_texts, list) else tgt_texts,
                **kwargs
            )
        
        # Batch processing
        rewards = []
        valid_indices = []
        comet_batch = []
        
        # First pass: format validation and extraction
        for i, (completion, src_text, tgt_text) in enumerate(zip(completions, src_texts, tgt_texts)):
            if not self._validate_format(completion):
                rewards.append(-2.0)  # Format penalty
                continue
                
            translation = self._extract_translation(completion)
            if not translation:
                rewards.append(-2.0)  # Extraction failure penalty
                continue
            
            # Prepare for COMET batch processing
            valid_indices.append(i)
            comet_batch.append({"src": src_text, "mt": translation, "ref": tgt_text})
            
            # Compute BLEU for this item
            bleu_score = self._compute_bleu(tgt_text, translation, kwargs.get('lg', 'en-zh'))
            rewards.append(1.0 + bleu_score / 100.0)  # Format + BLEU base score
        
        # Batch COMET computation for valid items
        if comet_batch:
            try:
                comet_output = self.comet_model.predict(comet_batch, batch_size=len(comet_batch), gpus=1, progress_bar=False)
                comet_scores = comet_output.scores
                
                # Add COMET scores to rewards
                comet_idx = 0
                for i in valid_indices:
                    rewards[i] += comet_scores[comet_idx]
                    comet_idx += 1
                    
            except Exception as e:
                print(f"Batch COMET computation failed: {e}")
                # Keep existing rewards (format + BLEU only)
        
        return rewards
    
    def _compute_single(self, completion, src_text, tgt_text, extra_info=None, **kwargs):
        """Single completion processing (original implementation)"""
        lg_pair = extra_info.get("lg", "en-zh") if extra_info else "en-zh"
        
        if not self._validate_format(completion):
            return -2.0
        
        translation = self._extract_translation(completion)
        if not translation:
            return -2.0
        
        bleu_score = self._compute_bleu(tgt_text, translation, lg_pair)
        
        # Single COMET computation
        comet_data = [{"src": src_text, "mt": translation, "ref": tgt_text}]
        comet_scores = self.comet_model.predict(comet_data, batch_size=1, gpus=1, progress_bar=False).scores
        comet_score = comet_scores[0]
        
        final_score = 1.0 + (bleu_score / 100.0) + comet_score
        return final_score
