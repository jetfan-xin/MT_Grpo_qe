#!/usr/bin/env python3
"""
GTPO调试集成测试
测试完整的GTPO训练流程中的调试信息输出
"""

import torch
import numpy as np
from collections import defaultdict

# 模拟导入GTPO相关模块
import sys
import os
sys.path.append('/Users/piko/Desktop/grpo/MT_Grpo/verl')

from verl import DataProto
from verl.workers.reward_manager.gtpo import GTPORewardManager
from verl.trainer.ppo.core_algos import compute_grpo_outcome_advantage

def create_mock_data():
    """创建模拟的训练数据"""
    bs = 4
    seq_len = 8  
    response_len = 6
    vocab_size = 1000
    
    # 创建mock data
    prompts = torch.randint(0, vocab_size, (bs, seq_len - response_len))
    responses = torch.randint(0, vocab_size, (bs, response_len))
    
    # 创建attention mask (有不同的序列长度)
    attention_mask = torch.ones(bs, seq_len)
    attention_mask[1, -1] = 0  # 第二个序列短一点
    attention_mask[3, -2:] = 0  # 第四个序列更短
    
    # 创建entropy数据 (模拟从模型计算得到)
    entropys = torch.randn(bs, response_len).abs() + 1.0  # 保证为正
    
    # 创建mock batch数据
    batch_data = {
        "prompts": prompts,
        "responses": responses, 
        "attention_mask": attention_mask,
        "entropys": entropys,  # 预计算的entropy
    }
    
    # 创建non_tensor_batch数据
    non_tensor_batch_list = []
    uids = ["prompt_0", "prompt_0", "prompt_1", "prompt_1"]  # 两个prompt组
    
    for i in range(bs):
        non_tensor_batch_list.append({
            "reward_model": {"ground_truth": f"Reference translation {i}"},
            "data_source": "test",
            "uid": uids[i],
            "extra_info": None
        })
    
    # 创建DataProto
    data = DataProto.from_single_dict({
        "tensor_batch": batch_data,
        "non_tensor_batch_list": non_tensor_batch_list
    })
    
    return data

def test_gtpo_reward_manager():
    """测试GTPO reward manager的调试输出"""
    print("🔍 TESTING GTPO REWARD MANAGER DEBUG OUTPUT")
    print("="*60)
    
    # 创建模拟tokenizer
    class MockTokenizer:
        def __init__(self):
            self.eos_token = "</s>"
        
        def decode(self, ids, skip_special_tokens=True):
            return f"decoded_text_{len(ids)}_tokens"
    
    # 创建模拟reward function
    def mock_compute_score(data_sources, solution_strs, ground_truths, extra_infos, **kwargs):
        scores = []
        for i in range(len(solution_strs)):
            # 给不同的回答不同的分数
            score = 0.5 + (hash(solution_strs[i]) % 100) / 200.0  # 0.5-1.0之间
            scores.append(score)
        return scores
    
    # 创建GTPO reward manager
    gtpo_manager = GTPORewardManager(
        tokenizer=MockTokenizer(),
        num_examine=2,  # 只打印前2个样本的详细信息
        compute_score=mock_compute_score,
        entropy_beta=1.5,  # 使用非默认值测试
        entropy_normalization="softmax"
    )
    
    # 创建测试数据
    data = create_mock_data()
    
    print("\n📊 Input data info:")
    print(f"   Batch size: {len(data)}")
    print(f"   Prompt shape: {data.batch['prompts'].shape}")
    print(f"   Response shape: {data.batch['responses'].shape}")
    print(f"   Entropy shape: {data.batch['entropys'].shape}")
    print(f"   UIDs: {[item['uid'] for item in data.non_tensor_batch_list]}")
    
    # 调用reward manager (这会触发所有的调试输出)
    print(f"\n🚀 CALLING GTPO REWARD MANAGER...")
    try:
        reward_result = gtpo_manager(data, return_dict=True)
        reward_tensor = reward_result["reward_tensor"]
        reward_extra_info = reward_result["reward_extra_info"]
        
        print(f"\n✅ GTPO Reward computation successful!")
        print(f"📊 Reward tensor shape: {reward_tensor.shape}")
        print(f"📈 Non-zero rewards: {(reward_tensor != 0).sum()}")
        print(f"🎯 Extra info keys: {list(reward_extra_info.keys())}")
        
    except Exception as e:
        print(f"❌ GTPO Reward computation failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

def test_baseline_computation():
    """测试baseline计算的调试输出"""
    print(f"\n🔍 TESTING BASELINE COMPUTATION DEBUG OUTPUT")
    print("="*60)
    
    # 创建测试数据
    bs = 6
    response_len = 8
    
    # 创建token-level rewards (有不同的长度和分数)
    token_level_rewards = torch.zeros(bs, response_len)
    scores = [0.8, 0.6, 0.9, 0.7, 0.5, 0.85]  # 不同的sequence奖励
    
    response_mask = torch.tensor([
        [1, 1, 1, 1, 1, 0, 0, 0],  # 5 tokens
        [1, 1, 1, 1, 1, 1, 0, 0],  # 6 tokens  
        [1, 1, 1, 0, 0, 0, 0, 0],  # 3 tokens
        [1, 1, 1, 1, 1, 1, 1, 0],  # 7 tokens
        [1, 1, 0, 0, 0, 0, 0, 0],  # 2 tokens
        [1, 1, 1, 1, 1, 1, 1, 1],  # 8 tokens
    ], dtype=torch.float32)
    
    # 将score分配给最后一个token
    for i in range(bs):
        last_token_idx = response_mask[i].sum().int() - 1
        token_level_rewards[i, last_token_idx] = scores[i]
    
    # 创建index (group IDs) - 3个groups，每个2个序列
    index = np.array([0, 0, 1, 1, 2, 2])
    
    print(f"\n📊 Test setup:")
    print(f"   Batch size: {bs}")
    print(f"   Groups: {len(set(index))}")
    for group_id in sorted(set(index)):
        group_indices = np.where(index == group_id)[0]
        group_scores = [scores[i] for i in group_indices]
        group_lengths = [response_mask[i].sum().int().item() for i in group_indices]
        print(f"   Group {group_id}: indices {group_indices.tolist()}, scores {group_scores}, lengths {group_lengths}")
    
    # 测试sequence-level baseline
    print(f"\n🧮 Testing sequence-level baseline...")
    try:
        advantages_seq, returns_seq = compute_grpo_outcome_advantage(
            token_level_rewards=token_level_rewards,
            response_mask=response_mask,
            index=index,
            epsilon=1e-6,
            norm_adv_by_std_in_grpo=True,
            baseline_mode="sequence_level"
        )
        print(f"✅ Sequence-level baseline successful!")
        
    except Exception as e:
        print(f"❌ Sequence-level baseline failed: {e}")
        return False
    
    # 测试token-level baseline  
    print(f"\n🧮 Testing token-level baseline...")
    try:
        advantages_tok, returns_tok = compute_grpo_outcome_advantage(
            token_level_rewards=token_level_rewards,
            response_mask=response_mask,
            index=index,
            epsilon=1e-6,
            norm_adv_by_std_in_grpo=True,
            baseline_mode="token_level"
        )
        print(f"✅ Token-level baseline successful!")
        
    except Exception as e:
        print(f"❌ Token-level baseline failed: {e}")
        return False
        
    # 比较两种方法的结果
    print(f"\n📊 Comparison of baseline methods:")
    for i in range(bs):
        seq_adv = advantages_seq[i, 0].item()  # 取第一个token的advantage
        tok_adv = advantages_tok[i, 0].item()
        print(f"   Seq {i} (Group {index[i]}): seq_level={seq_adv:.6f}, token_level={tok_adv:.6f}, diff={abs(seq_adv - tok_adv):.6f}")
    
    return True

if __name__ == "__main__":
    print("🧪 GTPO DEBUG INTEGRATION TEST SUITE")
    print("="*80)
    
    success = True
    
    # 测试GTPO reward manager
    if not test_gtpo_reward_manager():
        success = False
    
    # 测试baseline计算
    if not test_baseline_computation():
        success = False
    
    if success:
        print(f"\n✅ ALL GTPO DEBUG INTEGRATION TESTS PASSED!")
        print("🎯 Debug outputs are working correctly across all components.")
        print("📊 Ready for real training with comprehensive debugging!")
        print("\n💡 Usage for real training:")
        print("   1. Run: bash custom_gtpo_fast.sh")
        print("   2. Monitor debug outputs to verify algorithm correctness")
        print("   3. Check that entropy bonuses are applied correctly")
        print("   4. Verify baseline computation matches expected mode")
    else:
        print(f"\n❌ SOME GTPO DEBUG INTEGRATION TESTS FAILED!")
        print("🔧 Please check the error messages above and fix issues before training.")