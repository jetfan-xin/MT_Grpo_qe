#!/usr/bin/env python3
"""
Test GTPO entropy shape handling logic (without Ray dependencies)
直接测试entropy形状处理逻辑
"""

import torch
import torch.nn.functional as F

def test_entropy_shape_logic():
    """Test the entropy shape handling logic directly"""
    
    # Test parameters
    batch_size = 2
    prompt_len = 8  
    response_len = 6
    full_seq_len = prompt_len + response_len  # 14
    
    print("=== Testing GTPO Entropy Shape Logic ===")
    print(f"Batch size: {batch_size}")
    print(f"Prompt length: {prompt_len}")  
    print(f"Response length: {response_len}")
    print(f"Full sequence length: {full_seq_len}")
    
    # Mock response_mask
    response_mask = torch.ones(batch_size, response_len, dtype=torch.float32)
    
    def test_entropy_extraction(entropys, case_name):
        """Test entropy extraction logic"""
        print(f"\n=== {case_name} ===")
        print(f"Input entropy shape: {entropys.shape}")
        
        # This is the logic from our GTPO implementation
        response_len = response_mask.shape[-1]
        
        # Check entropy shape to determine if it includes prompt or not
        if entropys.shape[-1] == prompt_len + response_len:
            # Case 1: entropy includes prompt + response (use_remove_padding=True)
            print("GTPO: Entropy includes prompt+response, extracting response part")
            token_entropy = entropys[:, prompt_len:]  # Extract response part
        elif entropys.shape[-1] == response_len:
            # Case 2: entropy only has response part (use_remove_padding=False)
            print("GTPO: Entropy is response-only")
            token_entropy = entropys
        else:
            # Unexpected shape, try to handle gracefully
            print(f"GTPO: Unexpected entropy shape {entropys.shape}, expected full_len={prompt_len + response_len} or response_len={response_len}")
            # Try to take the last response_len tokens
            if entropys.shape[-1] >= response_len:
                token_entropy = entropys[:, -response_len:]
            else:
                raise ValueError(f"GTPO: Cannot extract response entropy from shape {entropys.shape}")
        
        print(f"Extracted token_entropy shape: {token_entropy.shape}")
        print(f"Expected shape: {response_mask.shape}")
        
        # Validate shape
        if token_entropy.shape == response_mask.shape:
            print("✅ Shape validation passed!")
            return token_entropy
        else:
            print(f"❌ Shape mismatch: {token_entropy.shape} vs {response_mask.shape}")
            return None
    
    # Test Case 1: Full sequence entropy (use_remove_padding=True)
    full_entropy = torch.rand(batch_size, full_seq_len) * 2.0 + 1.0
    result1 = test_entropy_extraction(full_entropy, "Full Sequence Entropy")
    
    # Test Case 2: Response-only entropy (use_remove_padding=False)
    response_entropy = torch.rand(batch_size, response_len) * 2.0 + 1.0
    result2 = test_entropy_extraction(response_entropy, "Response-Only Entropy")
    
    # Test Case 3: Unexpected shape (longer)
    weird_entropy = torch.rand(batch_size, response_len + 3) * 2.0 + 1.0
    result3 = test_entropy_extraction(weird_entropy, "Unexpected Shape (Longer)")
    
    # Test Case 4: Too short (should fail)
    print(f"\n=== Too Short Entropy (Should Fail) ===")
    try:
        short_entropy = torch.rand(batch_size, response_len - 2) * 2.0 + 1.0
        result4 = test_entropy_extraction(short_entropy, "Too Short Entropy")
        print("❌ Should have failed!")
        return False
    except ValueError as e:
        print(f"✅ Correctly failed with error: {e}")
    
    # Test GTPO formula application
    print(f"\n=== GTPO Formula Application Test ===")
    if result1 is not None and result2 is not None:
        # Test the actual GTPO formula with extracted entropy
        entropy_beta = 1.0
        
        for i, (entropy_data, case_name) in enumerate([(result1, "Full Sequence"), (result2, "Response-Only")]):
            print(f"\n--- {case_name} Case ---")
            
            # Apply GTPO formula: α * (Hi,t / Σ(k=1 to n)Hk,t) * dt
            entropy_bonus = torch.zeros_like(entropy_data)
            
            for t in range(response_len):
                entropy_t = entropy_data[:, t]  # (bs,)
                active_mask_t = response_mask[:, t]  # (bs,)
                dt = active_mask_t.sum()  # Number of active sequences
                
                if dt > 0:
                    entropy_sum_t = (entropy_t * active_mask_t).sum()
                    
                    if entropy_sum_t > 1e-8:
                        # Apply GTPO formula
                        entropy_bonus[:, t] = (entropy_beta * 
                                             (entropy_t / entropy_sum_t) * 
                                             dt * active_mask_t)
                    else:
                        # Uniform bonus if all entropies are zero
                        entropy_bonus[:, t] = (entropy_beta * 
                                             (1.0 / dt) * dt * active_mask_t)
            
            print(f"Entropy bonus shape: {entropy_bonus.shape}")
            print(f"Entropy bonus sum: {entropy_bonus.sum():.4f}")
            print(f"Bonus per sequence: {entropy_bonus.sum(dim=1).tolist()}")
    
    return True

if __name__ == "__main__":
    try:
        success = test_entropy_shape_logic()
        if success:
            print("\n🎉 All entropy shape logic tests passed!")
        else:
            print("\n💥 Some tests failed!")
    except Exception as e:
        print(f"\n💥 Test execution failed: {e}")
        import traceback
        traceback.print_exc()