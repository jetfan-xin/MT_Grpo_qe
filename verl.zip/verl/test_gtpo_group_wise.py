#!/usr/bin/env python3
"""
测试新的GROUP-WISE GTPO实现
"""

import torch
import numpy as np
from collections import defaultdict

def simulate_gtpo_group_wise():
    """模拟组内GTPO计算来验证实现正确性"""
    print("🧪 TESTING GROUP-WISE GTPO IMPLEMENTATION")
    print("="*70)
    
    # 模拟数据：2个prompt，每个prompt 3个response
    # Group 1: prompt_1 有3个response，奖励为 [1.0, -3.0, 0.8] (2个成功)
    # Group 2: prompt_2 有3个response，奖励为 [-3.0, -3.0, 1.2] (1个成功)
    
    uids = ["prompt_1", "prompt_1", "prompt_1", "prompt_2", "prompt_2", "prompt_2"]
    base_rewards = torch.tensor([1.0, -3.0, 0.8, -3.0, -3.0, 1.2])
    
    # 模拟response lengths
    response_lengths = [4, 3, 5, 2, 4, 3]
    max_len = max(response_lengths)
    
    # 创建response mask
    response_mask = torch.zeros(len(base_rewards), max_len)
    for i, length in enumerate(response_lengths):
        response_mask[i, :length] = 1.0
    
    # 模拟entropy数据
    token_entropy = torch.tensor([
        [2.0, 1.5, 1.0, 0.5, 0.0],  # Group1, seq0 (successful)
        [1.8, 1.2, 0.9, 0.0, 0.0],  # Group1, seq1 (unsuccessful)  
        [2.2, 1.8, 1.4, 1.0, 0.6],  # Group1, seq2 (successful)
        [1.5, 1.0, 0.0, 0.0, 0.0],  # Group2, seq0 (unsuccessful)
        [1.9, 1.3, 0.8, 0.4, 0.0],  # Group2, seq1 (unsuccessful)
        [2.1, 1.6, 1.2, 0.0, 0.0],  # Group2, seq2 (successful)
    ])
    
    print(f"📊 Test Setup:")
    print(f"   UIDs: {uids}")
    print(f"   Base rewards: {base_rewards.tolist()}")
    print(f"   Response lengths: {response_lengths}")
    
    # Apply mask to entropy
    token_entropy = token_entropy * response_mask
    successful_mask = base_rewards > 0
    
    # Group sequences by UID
    uid_to_indices = defaultdict(list)
    for idx, uid in enumerate(uids):
        uid_to_indices[uid].append(idx)
    
    print(f"\n🎯 GROUP-WISE GTPO CALCULATION")
    
    # Initialize entropy bonus
    entropy_bonus = torch.zeros_like(token_entropy)
    entropy_beta = 1.0
    
    # Process each group
    for group_id, (uid, seq_indices) in enumerate(uid_to_indices.items()):
        print(f"\n🔍 Group {group_id} ({uid}): indices {seq_indices}")
        
        # Extract group data
        group_base_rewards = base_rewards[seq_indices]
        group_successful_mask = successful_mask[seq_indices]
        group_token_entropy = token_entropy[seq_indices]
        group_response_mask = response_mask[seq_indices]
        
        num_successful_in_group = group_successful_mask.sum().item()
        print(f"   Successful: {num_successful_in_group}/{len(seq_indices)}")
        print(f"   Group rewards: {group_base_rewards.tolist()}")
        print(f"   Successful mask: {group_successful_mask.tolist()}")
        
        if num_successful_in_group == 0:
            print(f"   ⚠️  No successful sequences, skipping")
            continue
            
        # Apply GTPO formula for each time step
        for t in range(max_len):
            group_entropy_t = group_token_entropy[:, t]
            group_active_mask_t = group_response_mask[:, t]
            
            # Only successful sequences in this group
            group_successful_active_mask_t = group_successful_mask & group_active_mask_t.bool()
            dt_group = group_successful_active_mask_t.sum()
            
            if dt_group > 0:
                # Sum across successful sequences IN THIS GROUP
                entropy_sum_group_t = (group_entropy_t * group_successful_active_mask_t.float()).sum()
                
                if entropy_sum_group_t > 1e-8:
                    # GTPO formula within group
                    group_entropy_ratios = group_entropy_t / entropy_sum_group_t
                    group_entropy_bonus_t = (entropy_beta * 
                                           group_entropy_ratios * 
                                           dt_group * group_active_mask_t)
                    
                    # PAPER REQUIREMENT: Only assign to SUCCESSFUL sequences
                    for local_idx, global_idx in enumerate(seq_indices):
                        if group_successful_mask[local_idx]:  # Only successful sequences get bonus
                            entropy_bonus[global_idx, t] = group_entropy_bonus_t[local_idx]
                    
                    # Debug output for first few time steps
                    if t <= 2:
                        successful_entropies = group_entropy_t[group_successful_active_mask_t]
                        active_bonuses = group_entropy_bonus_t[group_active_mask_t.bool()]
                        print(f"   t={t}: dt_group={dt_group.int()} (≤16 ✅), active={group_active_mask_t.sum().int()}")
                        print(f"      Successful entropies: {successful_entropies.tolist()}")
                        print(f"      Entropy sum (group): {entropy_sum_group_t:.6f}")
                        print(f"      Active bonuses: {active_bonuses.tolist()}")
    
    # Verification
    print(f"\n📋 VERIFICATION RESULTS")
    print(f"✅ Total groups: {len(uid_to_indices)}")
    
    # Check dt values
    print(f"🎯 dt values verification:")
    for group_id, (uid, seq_indices) in enumerate(uid_to_indices.items()):
        group_successful = successful_mask[seq_indices].sum().item()
        print(f"   Group {group_id}: max dt = {group_successful} (should be ≤ 3 in this test)")
    
    # Show final rewards for successful sequences
    print(f"\n🏆 FINAL ENTROPY BONUSES:")
    for i in range(len(base_rewards)):
        is_successful = successful_mask[i]
        length = response_lengths[i] 
        bonus_sum = entropy_bonus[i, :length].sum().item()
        status = "SUCCESSFUL" if is_successful else "UNSUCCESSFUL"
        
        print(f"   Seq {i} ({status}): base_reward={base_rewards[i]:.1f}, bonus_sum={bonus_sum:.4f}")
        
        if is_successful:
            # Show token breakdown
            token_bonuses = entropy_bonus[i, :length]
            print(f"      Token bonuses: {token_bonuses.tolist()}")
    
    print(f"\n✅ GROUP-WISE GTPO TEST COMPLETED!")
    print(f"🎯 Key improvements:")
    print(f"   1. dt is now computed per-group (≤ rollout_n)")
    print(f"   2. Entropy normalization is within each prompt group")  
    print(f"   3. Different prompts don't affect each other")

if __name__ == "__main__":
    simulate_gtpo_group_wise()