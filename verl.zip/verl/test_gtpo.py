#!/usr/bin/env python3
"""
Test script for GTPO reward manager
"""

import torch
import numpy as np
from collections import defaultdict

# Mock DataProto for testing
class MockDataProto:
    def __init__(self):
        self.batch = {}
        self.non_tensor_batch = {}
    
    def __len__(self):
        return self.batch["responses"].shape[0]
    
    def __getitem__(self, idx):
        item = MockDataProto()
        item.batch = {k: v[idx:idx+1] if isinstance(v, torch.Tensor) else v[idx] 
                     for k, v in self.batch.items()}
        item.non_tensor_batch = self.non_tensor_batch[idx]
        return item

def test_gtpo_entropy_weights():
    """Test GTPO entropy weight computation"""
    
    # Import GTPO
    import sys
    sys.path.append('/Users/piko/Desktop/grpo/MT_Grpo/verl')
    from verl.workers.reward_manager.gtpo import GTPORewardManager
    
    # Mock tokenizer
    class MockTokenizer:
        def __init__(self):
            self.eos_token = "</s>"
            
        def decode(self, ids, skip_special_tokens=True):
            # Simple mock decode
            return f"decoded_text_{len(ids)}"
    
    # Mock compute_score function
    def mock_compute_score(**kwargs):
        return {"score": 0.8, "acc": True}
    
    # Create GTPO manager
    gtpo = GTPORewardManager(
        tokenizer=MockTokenizer(),
        num_examine=1,
        compute_score=mock_compute_score,
        entropy_beta=1.0,
        entropy_normalization="softmax"
    )
    
    # Create mock data
    batch_size = 2
    seq_len = 10
    response_len = 6
    vocab_size = 1000
    
    data = MockDataProto()
    
    # Mock batch data
    data.batch = {
        "prompts": torch.randint(0, vocab_size, (batch_size, seq_len - response_len)),
        "responses": torch.randint(0, vocab_size, (batch_size, response_len)),
        "attention_mask": torch.ones(batch_size, seq_len),
        # Method 1: Pre-computed entropys (preferred)
        "entropys": torch.rand(batch_size, seq_len) * 2.0 + 1.0,  # Random entropy values
        # Method 2: Raw logits (alternative)
        "logits": torch.randn(batch_size, seq_len, vocab_size),
    }
    
    # Mock non-tensor batch data
    data.non_tensor_batch = []
    for i in range(batch_size):
        data.non_tensor_batch.append({
            "reward_model": {"ground_truth": f"reference_text_{i}"},
            "data_source": "test",
            "extra_info": {"lg": "en-zh", "source": f"source_text_{i}"}
        })
    
    print("=== Testing GTPO Entropy Weight Computation ===")
    
    # Test entropy weight computation
    response_mask = data.batch["attention_mask"][:, seq_len-response_len:]
    entropy_weights = gtpo._compute_entropy_weights(data, response_mask)
    
    print(f"Response mask shape: {response_mask.shape}")
    print(f"Entropy weights shape: {entropy_weights.shape}")
    print(f"Entropy weights sum per sequence: {entropy_weights.sum(dim=-1)}")
    print(f"Sample entropy weights: {entropy_weights[0]}")
    
    # Test full reward computation
    print("\n=== Testing Full GTPO Reward Computation ===")
    result = gtpo(data, return_dict=True)
    
    reward_tensor = result["reward_tensor"]
    reward_extra_info = result["reward_extra_info"]
    
    print(f"Reward tensor shape: {reward_tensor.shape}")
    print(f"Reward tensor sum per sequence: {reward_tensor.sum(dim=-1)}")
    print(f"Sample token rewards: {reward_tensor[0]}")
    
    if "entropy_weights" in reward_extra_info:
        print(f"Entropy weights stored: {len(reward_extra_info['entropy_weights'])}")
        print(f"Token rewards stored: {len(reward_extra_info['token_rewards'])}")
    
    print("\n=== GTPO vs DAPO Comparison ===")
    print("DAPO: Only last token gets reward, others are 0")
    print(f"GTPO: All tokens get weighted rewards based on entropy")
    print(f"GTPO total reward preservation: {reward_tensor.sum(dim=-1)}")
    
    return True

def test_entropy_normalization_methods():
    """Test different entropy normalization methods"""
    
    print("\n=== Testing Entropy Normalization Methods ===")
    
    # Test data
    token_entropy = torch.tensor([[1.0, 2.0, 3.0, 1.5], [0.5, 1.0, 0.8, 2.0]])
    response_mask = torch.tensor([[1, 1, 1, 1], [1, 1, 1, 1]], dtype=torch.float32)
    
    # Import GTPO
    import sys
    sys.path.append('/Users/piko/Desktop/grpo/MT_Grpo/verl')
    from verl.workers.reward_manager.gtpo import GTPORewardManager
    
    class MockTokenizer:
        def decode(self, ids, skip_special_tokens=True):
            return "mock"
    
    methods = ["softmax", "minmax", "zscore"]
    
    for method in methods:
        print(f"\n--- {method.upper()} Normalization ---")
        
        gtpo = GTPORewardManager(
            tokenizer=MockTokenizer(),
            num_examine=0,
            entropy_normalization=method,
            entropy_beta=1.0,
            min_entropy_weight=0.1,
            max_entropy_weight=2.0
        )
        
        # Mock the normalization part
        if method == "softmax":
            weights = torch.softmax(token_entropy * gtpo.entropy_beta, dim=-1)
        elif method == "minmax":
            # Simple minmax for testing
            min_val, max_val = token_entropy.min(dim=-1, keepdim=True)[0], token_entropy.max(dim=-1, keepdim=True)[0]
            normalized = (token_entropy - min_val) / (max_val - min_val + 1e-8)
            weights = gtpo.min_entropy_weight + normalized * (gtpo.max_entropy_weight - gtpo.min_entropy_weight)
        elif method == "zscore":
            mean_val = token_entropy.mean(dim=-1, keepdim=True)
            std_val = token_entropy.std(dim=-1, keepdim=True)
            z_scores = (token_entropy - mean_val) / (std_val + 1e-8)
            weights = torch.sigmoid(z_scores * gtpo.entropy_beta)
            weights = gtpo.min_entropy_weight + weights * (gtpo.max_entropy_weight - gtpo.min_entropy_weight)
        
        weights = weights * response_mask
        
        print(f"Input entropy: {token_entropy}")
        print(f"Output weights: {weights}")
        print(f"Weights sum: {weights.sum(dim=-1)}")

if __name__ == "__main__":
    print("🚀 Testing GTPO Implementation")
    
    try:
        # Test basic functionality
        test_gtpo_entropy_weights()
        
        # Test normalization methods
        test_entropy_normalization_methods()
        
        print("\n✅ All GTPO tests passed!")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()