#!/usr/bin/env python3
"""
测试GTPO reward manager是否正确注册
"""

def test_gtpo_registration():
    """测试GTPO是否能正确导入和注册"""
    print("🔍 Testing GTPO Registration")
    print("="*40)
    
    try:
        # 测试导入
        print("1. 测试导入 reward manager registry...")
        from verl.workers.reward_manager import get_reward_manager_cls
        print("   ✅ Successfully imported get_reward_manager_cls")
        
        # 测试获取GTPO类
        print("2. 测试获取 GTPO reward manager...")
        gtpo_cls = get_reward_manager_cls("gtpo")
        print(f"   ✅ Successfully got GTPO class: {gtpo_cls}")
        print(f"   📋 Class name: {gtpo_cls.__name__}")
        print(f"   📄 Class module: {gtpo_cls.__module__}")
        
        # 测试创建实例 (简化版)
        print("3. 测试创建 GTPO 实例...")
        
        # 创建一个mock tokenizer
        class MockTokenizer:
            def __init__(self):
                self.eos_token = "</s>"
            def decode(self, ids, skip_special_tokens=True):
                return "mock_decoded_text"
        
        # 创建GTPO实例
        gtpo_instance = gtpo_cls(
            tokenizer=MockTokenizer(),
            num_examine=1,
            entropy_beta=1.0
        )
        print(f"   ✅ Successfully created GTPO instance")
        print(f"   📊 entropy_beta: {gtpo_instance.entropy_beta}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_all_reward_managers():
    """列出所有可用的reward managers"""
    print(f"\n🔍 Available Reward Managers")
    print("="*40)
    
    try:
        from verl.workers.reward_manager.registry import REWARD_MANAGER_REGISTRY
        
        print(f"Registered reward managers:")
        for name, cls in REWARD_MANAGER_REGISTRY.items():
            print(f"   • {name}: {cls.__name__}")
            
        return True
        
    except Exception as e:
        print(f"❌ Failed to list reward managers: {e}")
        return False

if __name__ == "__main__":
    print("🧪 GTPO REGISTRATION TEST")
    print("="*50)
    
    success1 = test_gtpo_registration()
    success2 = test_all_reward_managers()
    
    if success1 and success2:
        print(f"\n✅ GTPO Registration Test PASSED!")
        print("🚀 Ready to run GTPO training with:")
        print("   reward_model.reward_manager=gtpo")
    else:
        print(f"\n❌ GTPO Registration Test FAILED!")
        print("🔧 Please check the import and registration issues.")