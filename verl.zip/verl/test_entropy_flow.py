#!/usr/bin/env python3
"""
测试GTPO entropy数据流的逻辑
"""

def test_entropy_data_flow():
    """模拟GTPO训练中entropy数据的流动"""
    print("🔍 Testing GTPO Entropy Data Flow")
    print("="*50)
    
    # 模拟配置
    reward_manager_name = "gtpo"
    
    # 模拟数据结构
    class MockBatch:
        def __init__(self):
            self.batch = {}
            
    print(f"1. 检查reward manager配置...")
    if reward_manager_name == "gtpo":
        print("   ✅ GTPO reward manager detected")
    else:
        print("   ❌ Not using GTPO")
        
    print(f"\n2. 模拟pre-entropy计算...")
    new_batch = MockBatch()
    
    # 模拟pre-entropy计算结果
    import torch
    mock_entropy = torch.randn(4, 20)  # (batch_size, seq_len)
    
    print("   🔍 Pre-computing entropy for reward calculation...")
    pre_entropy_data = MockBatch()
    pre_entropy_data.batch = {"entropys": mock_entropy}
    
    if "entropys" in pre_entropy_data.batch:
        new_batch.batch["entropys"] = pre_entropy_data.batch["entropys"]
        print(f"   ✅ Added entropy data: shape={pre_entropy_data.batch['entropys'].shape}")
    else:
        print("   ⚠️  No entropy found in pre-computed log_prob data")
    
    print(f"\n3. 模拟reward计算...")
    print("   📊 Reward manager will now have access to entropy data")
    if "entropys" in new_batch.batch:
        print(f"   ✅ Entropy available for GTPO: shape={new_batch.batch['entropys'].shape}")
        print(f"   📈 Entropy stats: min={new_batch.batch['entropys'].min():.3f}, max={new_batch.batch['entropys'].max():.3f}")
    else:
        print("   ❌ No entropy data available - will use uniform entropy")
    
    print(f"\n4. 模拟old_log_prob计算...")
    batch = MockBatch()
    batch.batch = new_batch.batch.copy()  # 传递entropy数据
    
    if "entropys" in batch.batch and reward_manager_name == "gtpo":
        print("   🔄 GTPO: Reusing pre-computed entropy data for log_prob")
        entropys = batch.batch["entropys"]  # 使用预计算的entropy
    else:
        print("   🧮 Computing fresh entropy data")
        entropys = torch.randn(4, 20)  # 模拟新计算
        
    print(f"   📊 Entropy for metrics: shape={entropys.shape}")
    
    if reward_manager_name == "gtpo":
        print("   🔄 GTPO: Preserving entropy data for advantage computation")
        print("   ✅ Entropy data kept in batch for later use")
    else:
        print("   🗑️  Removing entropy data (not needed for DAPO)")
        
    print(f"\n5. 验证数据流...")
    flow_check = {
        "pre_entropy_computed": "entropys" in new_batch.batch,
        "reward_manager_access": "entropys" in new_batch.batch,
        "metrics_computed": entropys is not None,
        "data_preserved": reward_manager_name == "gtpo"
    }
    
    print("   数据流检查:")
    for step, status in flow_check.items():
        status_icon = "✅" if status else "❌"
        print(f"     {status_icon} {step}: {status}")
        
    all_good = all(flow_check.values())
    
    return all_good

if __name__ == "__main__":
    print("🧪 GTPO ENTROPY DATA FLOW TEST")
    print("="*60)
    
    success = test_entropy_data_flow()
    
    if success:
        print(f"\n✅ Entropy data flow CORRECT!")
        print("🎯 GTPO should now receive proper entropy data instead of uniform entropy.")
        print("🚀 Expected log message: '✅ GTPO: Using pre-computed entropys'")
    else:
        print(f"\n❌ Entropy data flow has issues!")
        print("🔧 Need to check the implementation.")