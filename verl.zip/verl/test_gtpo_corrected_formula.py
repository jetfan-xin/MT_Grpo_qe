#!/usr/bin/env python3
"""
测试修正后的GTPO公式：每个token都应该获得base_reward + entropy_bonus
"""

import torch
import numpy as np

def test_corrected_gtpo_formula():
    """测试修正后的GTPO公式实现"""
    print("🧪 TESTING CORRECTED GTPO FORMULA")
    print("="*70)
    
    # 模拟一个成功序列的情况
    base_reward = 1.5
    sequence_length = 4
    
    # 模拟entropy bonus (每个token不同的熵奖励)
    entropy_bonus = torch.tensor([0.8, 0.6, 0.4, 0.2])
    
    print(f"📊 Test setup:")
    print(f"   Base reward: {base_reward}")
    print(f"   Sequence length: {sequence_length}")
    print(f"   Entropy bonuses: {entropy_bonus.tolist()}")
    
    print(f"\n❌ OLD INCORRECT METHOD (only last token gets base_reward):")
    old_token_rewards = torch.zeros(sequence_length)
    old_token_rewards[-1] = base_reward  # Only last token
    old_token_rewards += entropy_bonus
    print(f"   Token rewards: {old_token_rewards.tolist()}")
    print(f"   Total reward: {old_token_rewards.sum():.4f}")
    
    print(f"\n✅ NEW CORRECT METHOD (all tokens get base_reward):")
    new_token_rewards = torch.full((sequence_length,), base_reward)  # ALL tokens get base reward
    new_token_rewards += entropy_bonus
    print(f"   Token rewards: {new_token_rewards.tolist()}")
    print(f"   Total reward: {new_token_rewards.sum():.4f}")
    
    print(f"\n📐 GTPO Formula verification:")
    print(f"   Formula: r̃i,t = ri + α * (Hi,t / Σ(k=1 to n)Hk,t) * dt")
    print(f"   Where ri = {base_reward} (sequence-level reward)")
    print(f"   Expected for each token t: {base_reward} + entropy_bonus[t]")
    
    print(f"\n🔍 Token-by-token verification:")
    for t in range(sequence_length):
        expected = base_reward + entropy_bonus[t].item()
        actual = new_token_rewards[t].item()
        print(f"   Token {t}: expected={expected:.4f}, actual={actual:.4f}, match={abs(expected-actual)<1e-6}")
    
    print(f"\n📊 Impact analysis:")
    old_total = old_token_rewards.sum().item()
    new_total = new_token_rewards.sum().item()
    difference = new_total - old_total
    multiplier = new_total / old_total if old_total != 0 else float('inf')
    
    print(f"   Old total: {old_total:.4f}")
    print(f"   New total: {new_total:.4f}")
    print(f"   Difference: +{difference:.4f}")
    print(f"   Multiplier: {multiplier:.2f}x")
    
    # Test unsuccessful sequence
    print(f"\n❌ UNSUCCESSFUL SEQUENCE TEST:")
    unsuccessful_base_reward = -3.0
    unsuccessful_token_rewards = torch.zeros(sequence_length)  # Should be all zeros
    print(f"   Base reward: {unsuccessful_base_reward}")
    print(f"   Token rewards (should be all 0): {unsuccessful_token_rewards.tolist()}")
    print(f"   All zeros: {torch.all(unsuccessful_token_rewards == 0.0).item()}")
    
    print(f"\n✅ GTPO FORMULA CORRECTION TEST COMPLETED!")
    print(f"🎯 Key insight: base_reward should be applied to ALL tokens, not just the last one")

if __name__ == "__main__":
    test_corrected_gtpo_formula()