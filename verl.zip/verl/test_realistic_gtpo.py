#!/usr/bin/env python3
"""
Test GTPO with realistic generation scenario
模拟真实的生成场景：16条序列，不同长度，从logits计算熵
"""

import torch
import torch.nn.functional as F

def test_realistic_gtpo_scenario():
    """模拟VERL实际训练中的GTPO计算"""
    print("=== 模拟真实GTPO场景 ===")
    
    # 模拟参数
    batch_size = 4  # 简化为4条序列（实际是16条）
    max_response_len = 6
    vocab_size = 1000
    entropy_beta = 1.0
    
    # 模拟不同长度的序列（通过attention mask体现）
    # 1: [tok1, tok2, tok3, tok4, <eos>, <pad>]
    # 2: [tok1, tok2, tok3, <eos>, <pad>, <pad>] 
    # 3: [tok1, tok2, <eos>, <pad>, <pad>, <pad>]
    # 4: [tok1, tok2, tok3, tok4, tok5, <eos>]
    
    response_mask = torch.tensor([
        [1, 1, 1, 1, 1, 0],  # 序列1: 5个token (包括eos)
        [1, 1, 1, 1, 0, 0],  # 序列2: 4个token 
        [1, 1, 1, 0, 0, 0],  # 序列3: 3个token
        [1, 1, 1, 1, 1, 1],  # 序列4: 6个token
    ], dtype=torch.float32)
    
    # 模拟每个位置的logits（生成时保存的概率分布）
    # 在实际训练中，这些logits来自模型的forward pass
    torch.manual_seed(42)  # 固定随机种子便于复现
    logits = torch.randn(batch_size, max_response_len, vocab_size)
    
    # 模拟不同熵的情况：
    # - 早期token通常熵较高（模型不确定）
    # - 后期token熵可能较低（模型更确定）
    
    # 调整logits分布来模拟不同的熵
    for i in range(batch_size):
        for t in range(max_response_len):
            if response_mask[i, t] > 0:  # 只处理有效token
                # 早期token: 更平坦的分布（高熵）
                if t < 2:
                    logits[i, t] = logits[i, t] * 0.5  # 较平坦
                # 后期token: 更尖锐的分布（低熵）
                else:
                    logits[i, t] = logits[i, t] * 2.0  # 较尖锐
    
    # 从logits计算token-level熵
    print("1. 从logits计算熵...")
    probs = F.softmax(logits, dim=-1)
    log_probs = F.log_softmax(logits, dim=-1)
    token_entropy = -(probs * log_probs).sum(dim=-1)  # (bs, response_len)
    
    # 应用mask
    token_entropy = token_entropy * response_mask
    
    print("Response mask (1=active, 0=padding):")
    print(response_mask.int())
    print("\nToken entropy:")
    print(token_entropy.round(decimals=3))
    
    # 应用GTPO公式
    print("\n2. 应用GTPO公式...")
    entropy_bonus = torch.zeros_like(token_entropy)
    
    print("时间步分析:")
    for t in range(max_response_len):
        entropy_t = token_entropy[:, t]
        active_mask_t = response_mask[:, t]
        dt = active_mask_t.sum().item()
        
        if dt > 0:
            entropy_sum_t = (entropy_t * active_mask_t).sum()
            
            if entropy_sum_t > 1e-8:
                bonus_t = (entropy_beta * (entropy_t / entropy_sum_t) * dt * active_mask_t)
                entropy_bonus[:, t] = bonus_t
                
                print(f"  t={t}: dt={int(dt)}, 总熵={entropy_sum_t:.3f}, 奖励分配={bonus_t.tolist()}")
            else:
                bonus_t = entropy_beta * (1.0 / dt) * dt * active_mask_t
                entropy_bonus[:, t] = bonus_t
                print(f"  t={t}: dt={int(dt)}, 零熵情况，均匀分配={bonus_t.tolist()}")
    
    # 模拟完整的GTPO奖励
    print("\n3. 完整GTPO奖励计算...")
    base_reward = 0.75  # 模拟COMET分数
    base_rewards = torch.tensor([base_reward] * batch_size)
    
    # DAPO对比：只给最后一个token奖励
    dapo_rewards = torch.zeros_like(token_entropy)
    for i in range(batch_size):
        valid_len = int(response_mask[i].sum())
        if valid_len > 0:
            dapo_rewards[i, valid_len-1] = base_rewards[i]
    
    # GTPO：最后token获得base reward + 所有token获得熵奖励
    gtpo_rewards = torch.zeros_like(token_entropy)
    for i in range(batch_size):
        valid_len = int(response_mask[i].sum())
        if valid_len > 0:
            gtpo_rewards[i, valid_len-1] = base_rewards[i]  # base reward
            gtpo_rewards[i, :valid_len] += entropy_bonus[i, :valid_len]  # entropy bonus
    
    print("\n=== 结果对比 ===")
    print("DAPO奖励 (只有最后token):")
    for i in range(batch_size):
        valid_len = int(response_mask[i].sum())
        print(f"  序列{i+1} (长度{valid_len}): {dapo_rewards[i, :valid_len].tolist()}")
    
    print("\nGTPO奖励 (最后token + 熵奖励):")
    for i in range(batch_size):
        valid_len = int(response_mask[i].sum())
        print(f"  序列{i+1} (长度{valid_len}): {gtpo_rewards[i, :valid_len].round(decimals=3).tolist()}")
    
    print(f"\n总奖励对比:")
    dapo_total = dapo_rewards.sum(dim=1)
    gtpo_total = gtpo_rewards.sum(dim=1)
    print(f"DAPO总计: {dapo_total.tolist()}")
    print(f"GTPO总计: {gtpo_total.round(decimals=3).tolist()}")
    print(f"GTPO额外奖励: {(gtpo_total - dapo_total).round(decimals=3).tolist()}")
    
    # 验证熵奖励的合理性
    print(f"\n=== 熵奖励分析 ===")
    print("高熵token应该获得更多奖励:")
    for i in range(batch_size):
        valid_len = int(response_mask[i].sum())
        seq_entropy = token_entropy[i, :valid_len]
        seq_bonus = entropy_bonus[i, :valid_len]
        print(f"序列{i+1}: 熵={seq_entropy.round(decimals=2).tolist()}, 奖励={seq_bonus.round(decimals=3).tolist()}")
    
    return True

if __name__ == "__main__":
    try:
        test_realistic_gtpo_scenario()
        print("\n✅ 真实场景GTPO测试通过!")
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()