#!/usr/bin/env python3
"""
Simple test for GTPO reward computation logic
"""

import torch
import torch.nn.functional as F

def test_gtpo_formula():
    """Test the GTPO formula implementation"""
    print("=== Testing GTPO Formula: r̃i,t = ri + α * (Hi,t / Σ(k=1 to n)Hk,t) * dt ===")
    
    # Mock data
    bs = 3  # batch size (3 sequences)
    response_len = 4  # response length
    entropy_beta = 1.0
    
    # Mock entropy values for each token position
    # Shape: (bs, response_len)
    token_entropy = torch.tensor([
        [1.0, 2.0, 1.5, 0.8],  # Sequence 1
        [0.5, 1.8, 2.2, 1.0],  # Sequence 2  
        [1.2, 1.0, 0.0, 0.0],  # Sequence 3 (ends early)
    ])
    
    # Response mask (1 = active, 0 = padded)
    response_mask = torch.tensor([
        [1, 1, 1, 1],  # Sequence 1: all 4 tokens
        [1, 1, 1, 1],  # Sequence 2: all 4 tokens
        [1, 1, 0, 0],  # Sequence 3: only 2 tokens
    ], dtype=torch.float32)
    
    # Apply mask to entropy
    token_entropy = token_entropy * response_mask
    
    print("Token entropy:")
    print(token_entropy)
    print("\nResponse mask:")
    print(response_mask)
    
    # Compute GTPO entropy bonus: α * (Hi,t / Σ(k=1 to n)Hk,t) * dt
    entropy_bonus = torch.zeros_like(token_entropy)
    
    for t in range(response_len):
        # Get entropy at time step t across all sequences
        entropy_t = token_entropy[:, t]  # (bs,)
        
        # Count how many sequences are still generating at time step t (dt)
        active_mask_t = response_mask[:, t]  # (bs,)
        dt = active_mask_t.sum()  # Number of active sequences
        
        print(f"\nTime step t={t}:")
        print(f"  Entropy at t: {entropy_t.tolist()}")
        print(f"  Active mask: {active_mask_t.tolist()}")
        print(f"  dt (active sequences): {dt}")
        
        if dt > 0:
            # Sum of entropies at time step t across all active sequences
            entropy_sum_t = (entropy_t * active_mask_t).sum()
            print(f"  Total entropy sum: {entropy_sum_t:.4f}")
            
            if entropy_sum_t > 1e-8:  # Avoid division by zero
                # Apply GTPO formula: α * (Hi,t / Σ(k=1 to n)Hk,t) * dt
                bonus_t = (entropy_beta * 
                          (entropy_t / entropy_sum_t) * 
                          dt * active_mask_t)
                entropy_bonus[:, t] = bonus_t
                print(f"  Entropy bonus: {bonus_t.tolist()}")
                
                # Verify: bonus should sum to α * dt for active sequences
                bonus_sum = bonus_t.sum()
                expected_sum = entropy_beta * dt
                print(f"  Bonus sum: {bonus_sum:.4f}, Expected: {expected_sum:.4f}")
            else:
                # If all entropies are zero, give uniform bonus
                bonus_t = (entropy_beta * (1.0 / dt) * dt * active_mask_t)
                entropy_bonus[:, t] = bonus_t
                print(f"  Uniform bonus: {bonus_t.tolist()}")
    
    print(f"\n=== Final Results ===")
    print("Entropy bonus matrix:")
    print(entropy_bonus)
    print(f"Bonus sum per sequence: {entropy_bonus.sum(dim=1)}")
    
    # Simulate full GTPO: base reward + entropy bonus
    base_reward = 0.8
    base_rewards = torch.tensor([base_reward, base_reward, base_reward])  # Same score for all
    
    print(f"\n=== GTPO vs DAPO Comparison ===")
    print(f"Base reward: {base_reward}")
    
    # DAPO: only last token gets reward
    dapo_rewards = torch.zeros_like(token_entropy)
    for i in range(bs):
        valid_len = int(response_mask[i].sum())
        if valid_len > 0:
            dapo_rewards[i, valid_len-1] = base_rewards[i]
    
    # GTPO: last token gets base reward + all tokens get entropy bonus
    gtpo_rewards = torch.zeros_like(token_entropy)
    for i in range(bs):
        valid_len = int(response_mask[i].sum())
        if valid_len > 0:
            # Base reward to last token
            gtpo_rewards[i, valid_len-1] = base_rewards[i]
            # Add entropy bonus to all tokens
            gtpo_rewards[i, :valid_len] += entropy_bonus[i, :valid_len]
    
    print("DAPO rewards (only last token):")
    print(dapo_rewards)
    print(f"DAPO total per sequence: {dapo_rewards.sum(dim=1)}")
    
    print("\nGTPO rewards (last token + entropy bonus):")
    print(gtpo_rewards)
    print(f"GTPO total per sequence: {gtpo_rewards.sum(dim=1)}")
    
    # Verify that GTPO gives higher reward to higher entropy tokens
    print(f"\n=== Entropy-based Credit Assignment ===")
    for i in range(bs):
        valid_len = int(response_mask[i].sum())
        if valid_len > 0:
            seq_entropy = token_entropy[i, :valid_len]
            seq_bonus = entropy_bonus[i, :valid_len]
            seq_total = gtpo_rewards[i, :valid_len]
            print(f"Sequence {i+1}:")
            print(f"  Token entropy: {seq_entropy.tolist()}")
            print(f"  Entropy bonus: {seq_bonus.tolist()}")
            print(f"  Total rewards: {seq_total.tolist()}")
    
    return True

if __name__ == "__main__":
    try:
        test_gtpo_formula()
        print("\n✅ GTPO formula test passed!")
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()