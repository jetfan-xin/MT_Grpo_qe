#!/usr/bin/env python3
"""
Test GTPO entropy shape handling
验证GTPO正确处理不同形状的entropy输入
"""

import torch
import torch.nn.functional as F
import sys
import os

# Add the verl path
sys.path.append('/Users/piko/Desktop/grpo/MT_Grpo/verl')

def test_entropy_shape_handling():
    """Test GTPO handles different entropy shapes correctly"""
    
    # Mock DataProto for testing
    class MockDataProto:
        def __init__(self):
            self.batch = {}
            self.non_tensor_batch = []
        
        def __len__(self):
            return self.batch["responses"].shape[0]
        
        def __getitem__(self, idx):
            item = MockDataProto()
            item.batch = {k: v[idx:idx+1] if isinstance(v, torch.Tensor) else v[idx] 
                         for k, v in self.batch.items()}
            item.non_tensor_batch = self.non_tensor_batch[idx]
            return item
    
    # Import GTPO
    from verl.workers.reward_manager.gtpo import GTPORewardManager
    
    # Mock tokenizer and compute_score
    class MockTokenizer:
        def __init__(self):
            self.eos_token = "</s>"
        def decode(self, ids, skip_special_tokens=True):
            return f"decoded_text_{len(ids)}"
    
    def mock_compute_score(**kwargs):
        return {"score": 0.8, "acc": True}
    
    # Create GTPO manager
    gtpo = GTPORewardManager(
        tokenizer=MockTokenizer(),
        num_examine=0,
        compute_score=mock_compute_score,
        entropy_beta=1.0,
        entropy_normalization="softmax"
    )
    
    # Test parameters
    batch_size = 2
    prompt_len = 8  
    response_len = 6
    full_seq_len = prompt_len + response_len  # 14
    vocab_size = 1000
    
    print("=== Testing GTPO Entropy Shape Handling ===")
    print(f"Batch size: {batch_size}")
    print(f"Prompt length: {prompt_len}")  
    print(f"Response length: {response_len}")
    print(f"Full sequence length: {full_seq_len}")
    
    # Base mock data
    base_data = MockDataProto()
    base_data.batch = {
        "prompts": torch.randint(0, vocab_size, (batch_size, prompt_len)),
        "responses": torch.randint(0, vocab_size, (batch_size, response_len)),
        "attention_mask": torch.ones(batch_size, full_seq_len),
    }
    
    base_data.non_tensor_batch = []
    for i in range(batch_size):
        base_data.non_tensor_batch.append({
            "reward_model": {"ground_truth": f"reference_text_{i}"},
            "data_source": "test",
            "extra_info": {"lg": "en-zh", "source": f"source_text_{i}"}
        })
    
    # Test Case 1: Full sequence entropy (use_remove_padding=True)
    print("\n=== Test Case 1: Full Sequence Entropy ===")
    data1 = MockDataProto()
    data1.batch = base_data.batch.copy()
    data1.non_tensor_batch = base_data.non_tensor_batch
    
    # Entropy for full sequence (prompt + response)
    full_entropy = torch.rand(batch_size, full_seq_len) * 2.0 + 1.0
    data1.batch["entropys"] = full_entropy
    
    print(f"Input entropy shape: {full_entropy.shape} (full sequence)")
    
    # Test entropy bonus computation
    attention_mask = data1.batch["attention_mask"]
    response_mask = attention_mask[:, prompt_len:]
    
    try:
        entropy_bonus1 = gtpo._compute_entropy_bonus(data1, response_mask)
        print(f"✅ Success! Output entropy bonus shape: {entropy_bonus1.shape}")
        print(f"Expected response shape: {response_mask.shape}")
        assert entropy_bonus1.shape == response_mask.shape, f"Shape mismatch: {entropy_bonus1.shape} vs {response_mask.shape}"
        print("✅ Shape validation passed!")
    except Exception as e:
        print(f"❌ Failed: {e}")
        return False
    
    # Test Case 2: Response-only entropy (use_remove_padding=False)
    print("\n=== Test Case 2: Response-Only Entropy ===")
    data2 = MockDataProto()
    data2.batch = base_data.batch.copy()
    data2.non_tensor_batch = base_data.non_tensor_batch
    
    # Entropy for response only
    response_entropy = torch.rand(batch_size, response_len) * 2.0 + 1.0
    data2.batch["entropys"] = response_entropy
    
    print(f"Input entropy shape: {response_entropy.shape} (response only)")
    
    try:
        entropy_bonus2 = gtpo._compute_entropy_bonus(data2, response_mask)
        print(f"✅ Success! Output entropy bonus shape: {entropy_bonus2.shape}")
        assert entropy_bonus2.shape == response_mask.shape, f"Shape mismatch: {entropy_bonus2.shape} vs {response_mask.shape}"
        print("✅ Shape validation passed!")
    except Exception as e:
        print(f"❌ Failed: {e}")
        return False
    
    # Test Case 3: Unexpected shape (should handle gracefully)
    print("\n=== Test Case 3: Unexpected Entropy Shape ===")
    data3 = MockDataProto()
    data3.batch = base_data.batch.copy()
    data3.non_tensor_batch = base_data.non_tensor_batch
    
    # Entropy with unexpected shape (longer than expected)
    weird_entropy = torch.rand(batch_size, response_len + 3) * 2.0 + 1.0  # 3 extra tokens
    data3.batch["entropys"] = weird_entropy
    
    print(f"Input entropy shape: {weird_entropy.shape} (unexpected length)")
    
    try:
        entropy_bonus3 = gtpo._compute_entropy_bonus(data3, response_mask)
        print(f"✅ Handled gracefully! Output entropy bonus shape: {entropy_bonus3.shape}")
        assert entropy_bonus3.shape == response_mask.shape, f"Shape mismatch: {entropy_bonus3.shape} vs {response_mask.shape}"
        print("✅ Graceful handling worked!")
    except Exception as e:
        print(f"❌ Failed to handle gracefully: {e}")
        return False
    
    # Test Case 4: No entropy (fallback)
    print("\n=== Test Case 4: No Entropy (Fallback) ===")
    data4 = MockDataProto()
    data4.batch = base_data.batch.copy()
    data4.non_tensor_batch = base_data.non_tensor_batch
    # No entropys field
    
    try:
        entropy_bonus4 = gtpo._compute_entropy_bonus(data4, response_mask)
        print(f"✅ Fallback worked! Output entropy bonus shape: {entropy_bonus4.shape}")
        assert entropy_bonus4.shape == response_mask.shape, f"Shape mismatch: {entropy_bonus4.shape} vs {response_mask.shape}"
        print("✅ Fallback validation passed!")
    except Exception as e:
        print(f"❌ Fallback failed: {e}")
        return False
    
    # Compare results
    print("\n=== Results Comparison ===")
    print(f"Full sequence entropy bonus sum: {entropy_bonus1.sum():.4f}")
    print(f"Response-only entropy bonus sum: {entropy_bonus2.sum():.4f}") 
    print(f"Unexpected shape entropy bonus sum: {entropy_bonus3.sum():.4f}")
    print(f"Fallback (uniform) entropy bonus sum: {entropy_bonus4.sum():.4f}")
    
    return True

if __name__ == "__main__":
    try:
        success = test_entropy_shape_handling()
        if success:
            print("\n🎉 All entropy shape tests passed!")
        else:
            print("\n💥 Some tests failed!")
            sys.exit(1)
    except Exception as e:
        print(f"\n💥 Test execution failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)