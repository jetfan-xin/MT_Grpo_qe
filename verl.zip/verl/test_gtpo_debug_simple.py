#!/usr/bin/env python3
"""
GTPO调试信息简化测试
不依赖Ray，直接测试核心组件的调试输出
"""

import torch
import numpy as np
from collections import defaultdict
import sys
import os

# Add the path for imports
sys.path.append('/Users/piko/Desktop/grpo/MT_Grpo/verl')

def test_baseline_computation_simple():
    """简化版本的baseline计算测试"""
    print("🔍 TESTING BASELINE COMPUTATION (SIMPLIFIED)")
    print("="*60)
    
    # 直接导入并测试core_algos中的函数
    try:
        from verl.trainer.ppo.core_algos import compute_grpo_outcome_advantage
        print("✅ Successfully imported compute_grpo_outcome_advantage")
    except Exception as e:
        print(f"❌ Failed to import compute_grpo_outcome_advantage: {e}")
        return False
    
    # 创建测试数据
    bs = 4
    response_len = 6
    
    # 创建token-level rewards
    token_level_rewards = torch.zeros(bs, response_len)
    scores = [0.8, 0.6, 0.9, 0.7]  # 不同的sequence奖励
    
    response_mask = torch.tensor([
        [1, 1, 1, 1, 0, 0],  # 4 tokens
        [1, 1, 1, 1, 1, 0],  # 5 tokens  
        [1, 1, 1, 0, 0, 0],  # 3 tokens
        [1, 1, 1, 1, 1, 1],  # 6 tokens
    ], dtype=torch.float32)
    
    # 将score分配给最后一个token
    for i in range(bs):
        last_token_idx = response_mask[i].sum().int() - 1
        token_level_rewards[i, last_token_idx] = scores[i]
    
    # 创建index (group IDs) - 2个groups
    index = np.array([0, 0, 1, 1])
    
    print(f"\n📊 Test setup:")
    print(f"   Token rewards shape: {token_level_rewards.shape}")
    print(f"   Response mask shape: {response_mask.shape}")
    print(f"   Groups: {list(set(index))}")
    print(f"   Scores: {scores}")
    
    # 测试sequence-level baseline
    print(f"\n🧮 Testing sequence-level baseline...")
    try:
        advantages_seq, returns_seq = compute_grpo_outcome_advantage(
            token_level_rewards=token_level_rewards,
            response_mask=response_mask,
            index=index,
            epsilon=1e-6,
            norm_adv_by_std_in_grpo=True,
            baseline_mode="sequence_level"
        )
        print(f"✅ Sequence-level baseline completed!")
        print(f"📊 Advantages shape: {advantages_seq.shape}")
        
    except Exception as e:
        print(f"❌ Sequence-level baseline failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # 测试token-level baseline  
    print(f"\n🧮 Testing token-level baseline...")
    try:
        advantages_tok, returns_tok = compute_grpo_outcome_advantage(
            token_level_rewards=token_level_rewards,
            response_mask=response_mask,
            index=index,
            epsilon=1e-6,
            norm_adv_by_std_in_grpo=True,
            baseline_mode="token_level"
        )
        print(f"✅ Token-level baseline completed!")
        print(f"📊 Advantages shape: {advantages_tok.shape}")
        
    except Exception as e:
        print(f"❌ Token-level baseline failed: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    return True

def test_entropy_bonus_computation():
    """测试entropy bonus计算"""
    print(f"\n🔍 TESTING ENTROPY BONUS COMPUTATION")
    print("="*60)
    
    print("📊 Manual entropy bonus calculation (following GTPO paper):")
    
    # 模拟entropy数据
    bs = 3
    seq_len = 4
    alpha = 1.0
    
    entropy_matrix = torch.tensor([
        [2.0, 1.5, 1.0, 0.5],  # 序列1
        [1.5, 2.5, 2.0, 0.0],  # 序列2 (3个token)
        [2.5, 2.0, 1.5, 1.0],  # 序列3
    ])
    
    response_mask = torch.tensor([
        [1, 1, 1, 1],  # 4 tokens
        [1, 1, 1, 0],  # 3 tokens
        [1, 1, 1, 1],  # 4 tokens
    ], dtype=torch.float32)
    
    print(f"   Entropy matrix:")
    for i in range(bs):
        active_len = response_mask[i].sum().int()
        print(f"     Seq {i}: {entropy_matrix[i, :active_len].tolist()}")
    
    # 手动计算GTPO公式
    entropy_bonus = torch.zeros_like(entropy_matrix)
    
    print(f"\n   GTPO Formula: α * (Hi,t / Σ(k=1 to n)Hk,t) * dt")
    
    for t in range(seq_len):
        entropy_t = entropy_matrix[:, t]
        active_mask_t = response_mask[:, t]
        dt = active_mask_t.sum()
        
        if dt > 0:
            entropy_sum_t = (entropy_t * active_mask_t).sum()
            print(f"\n   Time step t={t}:")
            print(f"     Active sequences: {dt.int()}")
            print(f"     Active entropies: {entropy_t[active_mask_t.bool()].tolist()}")
            print(f"     Entropy sum: {entropy_sum_t:.3f}")
            
            if entropy_sum_t > 1e-8:
                for i in range(bs):
                    if active_mask_t[i] > 0:
                        Hi_t = entropy_t[i]
                        bonus = alpha * (Hi_t / entropy_sum_t) * dt
                        entropy_bonus[i, t] = bonus
                        print(f"       Seq {i}: {alpha} * ({Hi_t:.1f} / {entropy_sum_t:.1f}) * {dt.int()} = {bonus:.6f}")
    
    print(f"\n📊 Final entropy bonuses:")
    for i in range(bs):
        active_len = response_mask[i].sum().int()
        bonus_sum = entropy_bonus[i, :active_len].sum()
        print(f"   Seq {i}: {entropy_bonus[i, :active_len].tolist()}")
        print(f"     Total bonus: {bonus_sum:.6f}")
    
    return True

def create_training_summary():
    """创建训练准备总结"""
    print(f"\n📋 GTPO TRAINING READINESS SUMMARY")
    print("="*60)
    
    print("✅ Components with debug output added:")
    print("   1. GTPO Reward Manager (verl/workers/reward_manager/gtpo.py)")
    print("      • Detailed entropy computation logging")
    print("      • Step-by-step GTPO formula application")
    print("      • Token-level reward distribution verification")
    print("")
    print("   2. Baseline Computation (verl/trainer/ppo/core_algos.py)")
    print("      • Sequence-level vs token-level baseline comparison")
    print("      • Group-wise statistics and manual verification")
    print("      • Advantage computation step-by-step logging")
    print("")
    print("   3. Training Loop (recipe/dapo/dapo_ray_trainer.py + verl/trainer/ppo/ray_trainer.py)")
    print("      • GRPO advantage estimation debug info")
    print("      • Algorithm configuration parameter passing")
    print("      • Training step progress indicators")
    
    print(f"\n🎯 Key debugging features:")
    print("   • Entropy source detection (pre-computed vs logits)")
    print("   • Cross-sequence entropy normalization verification")
    print("   • GTPO formula: r̃i,t = ri + α * (Hi,t / Σ(k=1 to n)Hk,t) * dt")
    print("   • Token-level vs sequence-level baseline comparison")
    print("   • Shape and numerical consistency checks")
    
    print(f"\n🚀 Ready for training with:")
    print("   • bash custom_gtpo_fast.sh (GTPO with token-level baseline)")
    print("   • bash custom_dapo_with_token_baseline.sh (DAPO comparison)")
    
    print(f"\n💡 What to monitor during training:")
    print("   1. Entropy computation method (should use pre-computed entropys)")
    print("   2. GTPO formula application at each time step")
    print("   3. Baseline mode confirmation (token_level vs sequence_level)")
    print("   4. Advantage computation statistics")
    print("   5. Non-zero reward distribution across tokens")
    
    return True

if __name__ == "__main__":
    print("🧪 GTPO DEBUG SIMPLE TEST SUITE")
    print("="*80)
    
    success = True
    
    # 测试baseline计算
    if not test_baseline_computation_simple():
        success = False
    
    # 测试entropy bonus计算
    if not test_entropy_bonus_computation():
        success = False
    
    # 创建训练总结
    create_training_summary()
    
    if success:
        print(f"\n✅ ALL SIMPLIFIED DEBUG TESTS PASSED!")
        print("🎯 GTPO implementation is ready for real training with comprehensive debugging.")
        print("\n🏁 Next step: Run 'bash custom_gtpo_fast.sh' and monitor the debug output!")
    else:
        print(f"\n❌ SOME DEBUG TESTS FAILED!")
        print("🔧 Please check the implementation before proceeding.")