#!/usr/bin/env python3
"""
测试reward_extra_info是否会导致numpy形状问题
"""

import numpy as np
from collections import defaultdict

def test_reward_extra_info_shapes():
    """测试不同长度的数据是否会导致numpy数组问题"""
    print("🔍 Testing reward_extra_info shapes")
    print("="*40)
    
    # 模拟GTPO返回的reward_extra_info
    reward_extra_info = defaultdict(list)
    
    # 模拟不同长度的序列数据
    sequences = [
        {"length": 5, "base_reward": 0.8},
        {"length": 8, "base_reward": 0.6}, 
        {"length": 3, "base_reward": 0.9},
        {"length": 6, "base_reward": 0.7},
    ]
    
    print("Simulating GTPO reward computation...")
    
    for i, seq in enumerate(sequences):
        base_reward = seq["base_reward"]
        length = seq["length"]
        
        # 模拟entropy_bonus和token_rewards (不同长度)
        entropy_bonus = np.random.rand(length)
        token_rewards = np.random.rand(length) + base_reward
        
        print(f"  Seq {i}: length={length}, base_reward={base_reward:.1f}")
        
        # 旧版本 - 会导致问题
        print("  Old approach (problematic):")
        try:
            # 这种方式会导致形状不一致的错误
            test_arrays = [entropy_bonus, token_rewards]  # 不同长度的数组
            # np.array(test_arrays) 会失败
            print(f"    entropy_bonus shape: {entropy_bonus.shape}")
            print(f"    token_rewards shape: {token_rewards.shape}")
            print("    ❌ Would fail when converted to numpy array")
        except Exception as e:
            print(f"    Error: {e}")
        
        # 新版本 - 存储标量值
        print("  New approach (fixed):")
        reward_extra_info["base_rewards"].append(base_reward)
        reward_extra_info["entropy_bonus_sum"].append(entropy_bonus.sum())
        reward_extra_info["entropy_bonus_mean"].append(entropy_bonus.mean())
        reward_extra_info["token_rewards_sum"].append(token_rewards.sum())
        print("    ✅ Storing scalar values only")
    
    print(f"\nTesting numpy array conversion...")
    
    try:
        # 测试新方法是否能成功转换为numpy数组
        result = {}
        for k, v in reward_extra_info.items():
            result[k] = np.array(v)
            print(f"  ✅ {k}: shape={result[k].shape}, dtype={result[k].dtype}")
            
        print(f"\n✅ All conversions successful!")
        print(f"📊 reward_extra_info keys: {list(reward_extra_info.keys())}")
        
        return True
        
    except Exception as e:
        print(f"❌ Conversion failed: {e}")
        return False

if __name__ == "__main__":
    print("🧪 REWARD EXTRA INFO SHAPE TEST")
    print("="*50)
    
    success = test_reward_extra_info_shapes()
    
    if success:
        print(f"\n✅ Shape issue FIXED!")
        print("🚀 GTPO training should now work without numpy shape errors.")
    else:
        print(f"\n❌ Shape issue still exists!")
        print("🔧 Need further fixes.")